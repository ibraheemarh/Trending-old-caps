import asyncio
import json
import logging
import os
import re
import sqlite3
import time
from datetime import datetime, timezone
from typing import Any, Optional

import httpx
import websockets
from dotenv import load_dotenv
from telegram import Update
from telegram.constants import ChatType
from telegram.ext import (
    Application, CommandHandler, ContextTypes, MessageHandler, filters
)

load_dotenv()

# ----------------------------- Configuration -----------------------------
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
GROUP_ID = int(os.getenv("TELEGRAM_GROUP_ID", "-1002656806095"))
ADMIN_IDS = {
    int(x.strip()) for x in os.getenv("TELEGRAM_ADMIN_IDS", "").split(",")
    if x.strip().isdigit()
}
SCAN_INTERVAL_SECONDS = max(600, int(os.getenv("SCAN_INTERVAL_SECONDS", "600")))
DB_PATH = os.getenv("DATABASE_PATH", "second_wave.sqlite3")

AVE_API_KEY = os.getenv("AVE_API_KEY", "").strip()
PUMPPORTAL_API_KEY = os.getenv("PUMPPORTAL_API_KEY", "").strip()
BUBBLEMAPS_API_KEY = os.getenv("BUBBLEMAPS_API_KEY", "").strip()
SOLSCAN_API_KEY = os.getenv("SOLSCAN_API_KEY", "").strip()
GMGN_API_KEY = os.getenv("GMGN_API_KEY", "").strip()  # optional; access is approval-based
ENABLE_PUMPPORTAL = os.getenv("ENABLE_PUMPPORTAL", "false").lower() == "true"
PUMPPORTAL_MINTS: set[str] = set()
PUMPPORTAL_LAST_EVENT = ""

# Initial screening values: tune after paper-testing, not investment guarantees.
MIN_LIQUIDITY_USD = float(os.getenv("MIN_LIQUIDITY_USD", "10000"))
MIN_MARKET_CAP_USD = float(os.getenv("MIN_MARKET_CAP_USD", "5000"))
MAX_MARKET_CAP_USD = float(os.getenv("MAX_MARKET_CAP_USD", "1000000"))
MIN_VOLUME_24H_USD = float(os.getenv("MIN_VOLUME_24H_USD", "10000"))
MIN_SCORE_TO_ALERT = int(os.getenv("MIN_SCORE_TO_ALERT", "7"))
ALERT_COOLDOWN_HOURS = float(os.getenv("ALERT_COOLDOWN_HOURS", "24"))
MAX_CANDIDATES_PER_SCAN = int(os.getenv("MAX_CANDIDATES_PER_SCAN", "80"))

DEX_BASE = "https://api.dexscreener.com"
AVE_BASE = "https://prod.ave-api.com/v2"
RUGCHECK_BASE = "https://api.rugcheck.xyz/v1"
GECKO_BASE = "https://api.geckoterminal.com/api/v2"

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
log = logging.getLogger("second-wave")


# ----------------------------- Persistence -------------------------------
def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                address TEXT NOT NULL,
                symbol TEXT,
                name TEXT,
                price_usd REAL,
                market_cap REAL,
                liquidity REAL,
                volume_24h REAL,
                created_at INTEGER NOT NULL
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_snapshots_address_time ON snapshots(address, created_at)")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                address TEXT NOT NULL,
                symbol TEXT,
                name TEXT,
                signal_price REAL NOT NULL,
                market_cap REAL,
                score INTEGER,
                reasons TEXT,
                created_at INTEGER NOT NULL
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_alerts_address_time ON alerts(address, created_at)")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS state (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        conn.execute(
            "INSERT OR IGNORE INTO state(key, value) VALUES('scanner_active', '0')"
        )
        conn.execute(
            "INSERT OR IGNORE INTO state(key, value) VALUES('last_scan', '')"
        )
        conn.execute(
            "INSERT OR IGNORE INTO state(key, value) VALUES('last_scan_candidates', '0')"
        )


def state_get(key: str, default: str = "") -> str:
    with db() as conn:
        row = conn.execute("SELECT value FROM state WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def state_set(key: str, value: str) -> None:
    with db() as conn:
        conn.execute(
            "INSERT INTO state(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )


def remember_snapshot(token: dict[str, Any]) -> None:
    with db() as conn:
        conn.execute(
            """INSERT INTO snapshots(address,symbol,name,price_usd,market_cap,liquidity,volume_24h,created_at)
               VALUES(?,?,?,?,?,?,?,?)""",
            (
                token["address"], token.get("symbol", ""), token.get("name", ""),
                token.get("price_usd"), token.get("market_cap"),
                token.get("liquidity"), token.get("volume_24h"), int(time.time())
            ),
        )
        # Keep the database compact.
        conn.execute("DELETE FROM snapshots WHERE created_at < ?", (int(time.time()) - 14 * 86400,))


def recent_snapshots(address: str, hours: int = 24) -> list[sqlite3.Row]:
    with db() as conn:
        rows = conn.execute(
            "SELECT * FROM snapshots WHERE address=? AND created_at>=? ORDER BY created_at ASC",
            (address, int(time.time()) - hours * 3600),
        ).fetchall()
    return rows


def latest_alert_time(address: str) -> int:
    with db() as conn:
        row = conn.execute(
            "SELECT created_at FROM alerts WHERE address=? ORDER BY created_at DESC LIMIT 1",
            (address,),
        ).fetchone()
    return int(row["created_at"]) if row else 0


def record_alert(token: dict[str, Any], score: int, reasons: list[str]) -> None:
    with db() as conn:
        conn.execute(
            """INSERT INTO alerts(address,symbol,name,signal_price,market_cap,score,reasons,created_at)
               VALUES(?,?,?,?,?,?,?,?)""",
            (
                token["address"], token.get("symbol", ""), token.get("name", ""),
                float(token.get("price_usd") or 0), token.get("market_cap"), score,
                json.dumps(reasons), int(time.time()),
            ),
        )


def alert_rows(limit: int = 100) -> list[sqlite3.Row]:
    with db() as conn:
        return conn.execute(
            "SELECT * FROM alerts ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()


# ------------------------------- HTTP/API --------------------------------
async def get_json(client: httpx.AsyncClient, url: str, **kwargs) -> Any:
    try:
        response = await client.get(url, timeout=15, **kwargs)
        response.raise_for_status()
        return response.json()
    except Exception as exc:
        log.debug("GET failed %s: %s", url, exc)
        return None


async def dex_discovery(client: httpx.AsyncClient) -> list[str]:
    """Return Solana token addresses discovered through public DexScreener feeds."""
    addresses: set[str] = set()
    endpoints = [
        f"{DEX_BASE}/token-profiles/latest/v1",
        f"{DEX_BASE}/token-boosts/latest/v1",
        f"{DEX_BASE}/token-boosts/top/v1",
    ]
    for endpoint in endpoints:
        payload = await get_json(client, endpoint)
        if isinstance(payload, list):
            for item in payload:
                if str(item.get("chainId", "")).lower() == "solana":
                    address = item.get("tokenAddress")
                    if address:
                        addresses.add(address)
    return list(addresses)[:MAX_CANDIDATES_PER_SCAN]


async def ave_discovery(client: httpx.AsyncClient) -> list[str]:
    if not AVE_API_KEY:
        return []
    headers = {"X-API-KEY": AVE_API_KEY}
    payload = await get_json(
        client, f"{AVE_BASE}/tokens/trending",
        params={"chain": "solana", "current_page": 0, "page_size": 100},
        headers=headers,
    )
    result: list[str] = []
    if isinstance(payload, dict):
        data = payload.get("data", [])
        if isinstance(data, dict):
            data = data.get("tokens", [])
        if isinstance(data, list):
            for item in data:
                address = item.get("token") or item.get("address") or item.get("token_address")
                if address:
                    result.append(str(address))
    return result


async def gecko_discovery(client: httpx.AsyncClient) -> list[str]:
    """Fallback discovery using GeckoTerminal's public Solana new-pools endpoint."""
    payload = await get_json(client, f"{GECKO_BASE}/networks/solana/new_pools")
    result: list[str] = []
    if not isinstance(payload, dict):
        return result
    for pool in payload.get("data", []):
        attrs = pool.get("attributes", {}) or {}
        # GeckoTerminal pool names often look like TOKEN / SOL. Token addresses
        # can be included as relationships, but are not always exposed here.
        rel = pool.get("relationships", {}) or {}
        base = ((rel.get("base_token") or {}).get("data") or {}).get("id", "")
        quote = ((rel.get("quote_token") or {}).get("data") or {}).get("id", "")
        for token_id in (base, quote):
            if "_" in token_id:
                address = token_id.split("_", 1)[1]
                if address and address != "So11111111111111111111111111111111111111112":
                    result.append(address)
    return result


async def token_pairs(client: httpx.AsyncClient, address: str) -> Optional[dict[str, Any]]:
    payload = await get_json(client, f"{DEX_BASE}/token-pairs/v1/solana/{address}")
    if not isinstance(payload, list) or not payload:
        return None
    # Select the pair with the greatest reported USD liquidity.
    pairs = [p for p in payload if p.get("chainId") == "solana"]
    if not pairs:
        return None
    pairs.sort(key=lambda p: float(((p.get("liquidity") or {}).get("usd") or 0)), reverse=True)
    pair = pairs[0]
    base = pair.get("baseToken") or {}
    price = safe_float(pair.get("priceUsd"))
    liq = safe_float((pair.get("liquidity") or {}).get("usd"))
    vol = pair.get("volume") or {}
    txns = pair.get("txns") or {}
    h1tx = txns.get("h1") or {}
    h24tx = txns.get("h24") or {}
    pc = pair.get("priceChange") or {}
    fdv = safe_float(pair.get("marketCap")) or safe_float(pair.get("fdv"))
    return {
        "address": address,
        "symbol": base.get("symbol") or "UNKNOWN",
        "name": base.get("name") or "Unknown token",
        "price_usd": price,
        "market_cap": fdv,
        "liquidity": liq,
        "volume_5m": safe_float(vol.get("m5")),
        "volume_1h": safe_float(vol.get("h1")),
        "volume_24h": safe_float(vol.get("h24")),
        "price_change_5m": safe_float(pc.get("m5")),
        "price_change_1h": safe_float(pc.get("h1")),
        "price_change_6h": safe_float(pc.get("h6")),
        "price_change_24h": safe_float(pc.get("h24")),
        "buys_1h": int(safe_float(h1tx.get("buys")) or 0),
        "sells_1h": int(safe_float(h1tx.get("sells")) or 0),
        "buys_24h": int(safe_float(h24tx.get("buys")) or 0),
        "sells_24h": int(safe_float(h24tx.get("sells")) or 0),
        "pair_url": pair.get("url") or f"https://dexscreener.com/solana/{address}",
        "pair_created_at": pair.get("pairCreatedAt"),
        "dex_id": pair.get("dexId", "unknown"),
    }


def safe_float(value: Any) -> Optional[float]:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


async def rugcheck_report(client: httpx.AsyncClient, address: str) -> Optional[dict[str, Any]]:
    payload = await get_json(client, f"{RUGCHECK_BASE}/tokens/{address}/report")
    return payload if isinstance(payload, dict) else None


async def ave_token_detail(client: httpx.AsyncClient, address: str) -> Optional[dict[str, Any]]:
    if not AVE_API_KEY:
        return None
    headers = {"X-API-KEY": AVE_API_KEY}
    payload = await get_json(client, f"{AVE_BASE}/tokens/{address}-solana", headers=headers)
    if isinstance(payload, dict):
        data = payload.get("data")
        if isinstance(data, dict):
            return data.get("token", data)
        if isinstance(data, list) and data:
            return data[0]
    return None


async def optional_holder_data(client: httpx.AsyncClient, address: str) -> dict[str, Any]:
    """
    Optional data enrichments. Solscan and Bubblemaps schemas/authentication can
    depend on the user's plan; only call when credentials are configured.
    """
    result: dict[str, Any] = {}
    if BUBBLEMAPS_API_KEY:
        headers = {"X-API-Key": BUBBLEMAPS_API_KEY}
        payload = await get_json(
            client,
            f"https://api.bubblemaps.io/v0/tokens/metadata/solana/{address}",
            params={"return_token_stats": "true"},
            headers=headers,
        )
        if isinstance(payload, dict):
            result["bubblemaps"] = payload
    if SOLSCAN_API_KEY:
        headers = {"token": SOLSCAN_API_KEY}
        payload = await get_json(
            client, "https://api-v2.solscan.io/v2/token/holders",
            params={"address": address, "page": 1, "page_size": 10},
            headers=headers,
        )
        if isinstance(payload, dict):
            result["solscan"] = payload
    # GMGN's documented trade API is approval-based and not a generic public
    # market-data endpoint. Do not assume a key unlocks undocumented routes.
    if GMGN_API_KEY:
        result["gmgn_note"] = "GMGN key configured; official API access is approval-based. No undocumented endpoint called."
    return result


# --------------------------- Strategy scoring ----------------------------
NARRATIVE_KEYWORDS = {
    "ai", "agent", "agents", "depin", "gaming", "game", "infra", "infrastructure",
    "compute", "robot", "robotics", "data", " rwa", "web3", " DePIN", "AI"
}


def score_token(token: dict[str, Any], risk: Optional[dict[str, Any]], ave: Optional[dict[str, Any]]) -> tuple[int, list[str], list[str]]:
    score = 0
    reasons: list[str] = []
    warnings: list[str] = []

    liq = token.get("liquidity") or 0
    mc = token.get("market_cap") or 0
    vol24 = token.get("volume_24h") or 0
    vol1 = token.get("volume_1h") or 0
    vol5 = token.get("volume_5m") or 0
    pc24 = token.get("price_change_24h")
    pc1 = token.get("price_change_1h")
    pc5 = token.get("price_change_5m")
    buys1, sells1 = token.get("buys_1h", 0), token.get("sells_1h", 0)
    text_blob = f'{token.get("name","")} {token.get("symbol","")}'.lower()

    if liq >= MIN_LIQUIDITY_USD:
        score += 2; reasons.append(f"Liquidity ${liq:,.0f} meets minimum")
    else:
        warnings.append(f"Liquidity below configured minimum (${liq:,.0f})")

    if MIN_MARKET_CAP_USD <= mc <= MAX_MARKET_CAP_USD:
        score += 1; reasons.append(f"Market cap ${mc:,.0f} is in target range")
    else:
        warnings.append(f"Market cap outside target range (${mc:,.0f})")

    if vol24 >= MIN_VOLUME_24H_USD:
        score += 1; reasons.append(f"24h volume ${vol24:,.0f}")
    else:
        warnings.append("24h volume below configured minimum")

    if pc24 is not None and -70 <= pc24 <= 250:
        score += 1; reasons.append(f"24h move {pc24:+.1f}%: not excessively extended")
    elif pc24 is not None:
        warnings.append(f"24h move is extreme ({pc24:+.1f}%)")

    if pc1 is not None and -45 <= pc1 <= 15:
        score += 1; reasons.append(f"1h change {pc1:+.1f}% is compatible with pullback/consolidation")
    if pc5 is not None and pc5 > 0:
        score += 1; reasons.append(f"5m momentum recovering ({pc5:+.1f}%)")

    if buys1 + sells1 >= 10 and buys1 > sells1:
        score += 1; reasons.append(f"1h buy transactions exceed sells ({buys1}/{sells1})")
    elif buys1 + sells1 >= 10:
        warnings.append(f"1h sells are not below buys ({buys1}/{sells1})")

    if vol1 and vol5 and vol5 * 12 > vol1:
        score += 1; reasons.append("Recent 5m volume is elevated versus the 1h average")

    if any(k.strip().lower() in text_blob for k in NARRATIVE_KEYWORDS):
        score += 1; reasons.append("Name/symbol keyword matches a tracked narrative (heuristic only)")

    # Track price history for a real observed post-launch correction/recovery.
    history = recent_snapshots(token["address"], 24)
    prices = [safe_float(r["price_usd"]) for r in history if safe_float(r["price_usd"]) and safe_float(r["price_usd"]) > 0]
    if len(prices) >= 3 and token.get("price_usd"):
        peak = max(prices)
        low_after_peak = min(prices[prices.index(peak):]) if peak in prices else min(prices)
        current = token["price_usd"]
        drawdown = (low_after_peak / peak - 1) * 100 if peak else 0
        rebound = (current / low_after_peak - 1) * 100 if low_after_peak else 0
        if -55 <= drawdown <= -8 and rebound >= 3:
            score += 2
            reasons.append(f"Observed pullback/recovery in bot history (pullback {drawdown:.1f}%, rebound {rebound:.1f}%)")
        else:
            reasons.append("Not enough historical evidence yet for a clean second-wave pattern")
    else:
        reasons.append("Building price history; second-wave pattern is not yet independently confirmed")

    if risk:
        risks = risk.get("risks") or []
        risk_names = [str(r.get("name", r.get("description", ""))).lower() for r in risks if isinstance(r, dict)]
        risk_text = " ".join(risk_names)
        if any(word in risk_text for word in ("mint authority", "freeze authority", "honeypot", "rug", "mutable", "creator holds")):
            score -= 3
            warnings.append("RugCheck report contains a potentially important risk flag; review full report")
        else:
            score += 1
            reasons.append("RugCheck report retrieved; no obvious high-risk keyword found (not a safety guarantee)")
    else:
        warnings.append("RugCheck data unavailable; risk check is incomplete")

    if ave:
        holders = safe_float(ave.get("holders"))
        if holders is not None and holders > 100:
            score += 1; reasons.append(f"Ave reports {int(holders):,} holders")
        ave_risk = str(ave.get("risk_level", "")).lower()
        if ave_risk in ("3", "4", "high", "very high"):
            score -= 3; warnings.append(f"Ave risk level: {ave_risk}")

    return score, reasons, warnings


# ------------------------------- Messaging --------------------------------
def is_admin(update: Update) -> bool:
    # If ADMIN_IDS is configured, restrict scanner controls to those IDs.
    # If left blank, commands remain available to group members for easy setup.
    return not ADMIN_IDS or bool(update.effective_user and update.effective_user.id in ADMIN_IDS)


async def reply(update: Update, text: str) -> None:
    if update.effective_message:
        await update.effective_message.reply_text(text, disable_web_page_preview=True)


def fmt_money(value: Any) -> str:
    try:
        n = float(value or 0)
    except (TypeError, ValueError):
        n = 0
    if n >= 1_000_000:
        return f"${n/1_000_000:.2f}M"
    if n >= 1_000:
        return f"${n/1_000:.1f}K"
    return f"${n:,.2f}"


async def analyze_address(client: httpx.AsyncClient, address: str) -> tuple[Optional[dict[str, Any]], Optional[dict[str, Any]], Optional[dict[str, Any]]]:
    token = await token_pairs(client, address)
    risk, ave = await asyncio.gather(
        rugcheck_report(client, address),
        ave_token_detail(client, address),
    )
    return token, risk, ave


async def send_signal(app: Application, token: dict[str, Any], score: int, reasons: list[str], warnings: list[str]) -> None:
    record_alert(token, score, reasons)
    reasons_text = "\n".join(f"• {r}" for r in reasons[:6]) or "• Setup matched preliminary screening rules"
    warnings_text = "\n".join(f"• {w}" for w in warnings[:4]) or "• Always verify manually before acting"
    msg = (
        f"🌊 <b>SECOND-WAVE WATCHLIST</b>\n\n"
        f"🪙 <b>{html_escape(token.get('name','Unknown'))} (${html_escape(token.get('symbol','?'))})</b>\n"
        f"🧾 <code>{html_escape(token['address'])}</code>\n"
        f"⛓ Chain: Solana | DEX: {html_escape(token.get('dex_id','unknown'))}\n"
        f"💵 Price: ${token.get('price_usd') or 0:.10g}\n"
        f"📊 Market cap/FDV: {fmt_money(token.get('market_cap'))}\n"
        f"💧 Liquidity: {fmt_money(token.get('liquidity'))}\n"
        f"📈 24h volume: {fmt_money(token.get('volume_24h'))}\n"
        f"📉 Price change: 5m {fmt_pct(token.get('price_change_5m'))} | "
        f"1h {fmt_pct(token.get('price_change_1h'))} | 24h {fmt_pct(token.get('price_change_24h'))}\n"
        f"🧠 Strategy score: <b>{score}</b>\n\n"
        f"<b>Why it matched</b>\n{reasons_text}\n\n"
        f"<b>Risk / data notes</b>\n{warnings_text}\n\n"
        f"🔎 <a href=\"{html_escape(token.get('pair_url','https://dexscreener.com/solana'))}\">Open on DexScreener</a>\n\n"
        f"⚠️ Research alert only—not a buy instruction or guaranteed second pump. Verify contract, holders, team, and liquidity."
    )
    await app.bot.send_message(
        chat_id=GROUP_ID, text=msg, parse_mode="HTML",
        disable_web_page_preview=True
    )


def fmt_pct(value: Any) -> str:
    if value is None:
        return "n/a"
    return f"{float(value):+.1f}%"


def html_escape(value: Any) -> str:
    import html
    return html.escape(str(value or ""))


async def pumpportal_listener() -> None:
    """Listen for Pump.fun new-token and migration events via PumpPortal.

    This is discovery only; the scanner still validates each mint through
    market-data and risk endpoints before sending any alert.
    """
    global PUMPPORTAL_LAST_EVENT
    url = "wss://pumpportal.fun/api/data"
    if PUMPPORTAL_API_KEY:
        url += f"?api-key={PUMPPORTAL_API_KEY}"
    while True:
        try:
            async with websockets.connect(url, ping_interval=20, ping_timeout=20, close_timeout=5) as ws:
                await ws.send(json.dumps({"method": "subscribeNewToken"}))
                await ws.send(json.dumps({"method": "subscribeMigration"}))
                log.info("PumpPortal websocket connected; subscribed to new-token and migration events")
                async for raw in ws:
                    try:
                        event = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    mint = event.get("mint") or event.get("tokenAddress") or event.get("token_address")
                    if mint and isinstance(mint, str):
                        PUMPPORTAL_MINTS.add(mint)
                        # Bound the in-memory queue so the process cannot grow forever.
                        if len(PUMPPORTAL_MINTS) > 5000:
                            PUMPPORTAL_MINTS.pop()
                        PUMPPORTAL_LAST_EVENT = datetime.now(timezone.utc).isoformat(timespec="seconds")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.warning("PumpPortal websocket disconnected: %s; reconnecting in 20 seconds", exc)
            await asyncio.sleep(20)


async def run_scan(app: Application, manual: bool = False) -> dict[str, int]:
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    state_set("last_scan", now)
    async with httpx.AsyncClient(headers={"User-Agent": "SecondWaveBot/1.0"}) as client:
        discovered_sets = await asyncio.gather(
            dex_discovery(client), ave_discovery(client), gecko_discovery(client),
            return_exceptions=True
        )
        addresses: set[str] = set()
        for result in discovered_sets:
            if isinstance(result, list):
                addresses.update(result)
        if ENABLE_PUMPPORTAL:
            addresses.update(PUMPPORTAL_MINTS)
        addresses = set(list(addresses)[:MAX_CANDIDATES_PER_SCAN])
        stats = {"discovered": len(addresses), "analyzed": 0, "alerts": 0, "errors": 0}

        # Scan sequentially to be considerate of public API rate limits.
        for address in addresses:
            try:
                token, risk, ave = await analyze_address(client, address)
                if not token or not token.get("price_usd"):
                    continue
                stats["analyzed"] += 1
                score, reasons, warnings = score_token(token, risk, ave)
                remember_snapshot(token)

                last_alert = latest_alert_time(address)
                cooled_down = time.time() - last_alert >= ALERT_COOLDOWN_HOURS * 3600
                hard_filters_pass = (
                    (token.get("liquidity") or 0) >= MIN_LIQUIDITY_USD
                    and MIN_MARKET_CAP_USD <= (token.get("market_cap") or 0) <= MAX_MARKET_CAP_USD
                    and (token.get("volume_24h") or 0) >= MIN_VOLUME_24H_USD
                )
                if score >= MIN_SCORE_TO_ALERT and hard_filters_pass and cooled_down:
                    await send_signal(app, token, score, reasons, warnings)
                    stats["alerts"] += 1
                await asyncio.sleep(0.15)
            except Exception as exc:
                stats["errors"] += 1
                log.warning("Token scan failed for %s: %s", address, exc)

    state_set("last_scan_candidates", str(stats["analyzed"]))
    log.info("Scan finished: %s", stats)
    return stats


async def scanner_loop(app: Application) -> None:
    while state_get("scanner_active", "0") == "1":
        try:
            await run_scan(app)
        except Exception:
            log.exception("Unexpected scanner failure")
        await asyncio.sleep(SCAN_INTERVAL_SECONDS)


async def post_init(app: Application) -> None:
    init_db()
    if ENABLE_PUMPPORTAL:
        app.create_task(pumpportal_listener())
    # If it was marked active before a restart, resume automatically.
    if state_get("scanner_active", "0") == "1":
        app.create_task(scanner_loop(app))


async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update):
        await reply(update, "You are not authorized to start the scanner.")
        return
    if state_get("scanner_active", "0") == "1":
        await reply(update, "🌊 Second-Wave scanner is already ACTIVE. It scans every 10 minutes.")
        return
    state_set("scanner_active", "1")
    await reply(update, "✅ Second-Wave scanner is now ACTIVE. Market scans run every 10 minutes; qualifying watchlist alerts go to the configured group.")
    context.application.create_task(scanner_loop(context.application))


async def scan_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update):
        await reply(update, "You are not authorized to run a manual scan.")
        return
    await reply(update, "🔎 Starting a manual scan. This can take a little while because the bot checks multiple data sources.")
    stats = await run_scan(context.application, manual=True)
    await reply(update, f"Scan complete.\nDiscovered: {stats['discovered']}\nAnalyzed: {stats['analyzed']}\nAlerts sent: {stats['alerts']}\nErrors: {stats['errors']}")


async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    active = state_get("scanner_active", "0") == "1"
    await reply(
        update,
        "🌊 SECOND-WAVE BOT STATUS\n"
        f"Scanner: {'ACTIVE' if active else 'STOPPED'}\n"
        f"Interval: {SCAN_INTERVAL_SECONDS // 60} minutes\n"
        f"Last scan (UTC): {state_get('last_scan', 'Not run yet')}\n"
        f"Last analyzed count: {state_get('last_scan_candidates', '0')}\n"
        f"Ave API: {'configured' if AVE_API_KEY else 'not configured'}\n"
        f"PumpPortal stream: {'enabled' if ENABLE_PUMPPORTAL else 'disabled'}\n"
        f"PumpPortal last event (UTC): {PUMPPORTAL_LAST_EVENT or 'none'}\n"
        f"GMGN key: {'configured (approval-based)' if GMGN_API_KEY else 'not configured'}\n"
        f"Destination group: {GROUP_ID}\n"
        "Note: API failures or provider rate limits can reduce coverage."
    )


async def pnl_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    rows = alert_rows(200)
    if not rows:
        await reply(update, "No signals recorded yet. PNL will appear after the bot sends its first alert and can retrieve a current price.")
        return
    # Use latest DexScreener price as a paper-tracking mark. This is NOT wallet PNL.
    total, winners, losers, checked = 0.0, 0, 0, 0
    examples: list[str] = []
    async with httpx.AsyncClient(headers={"User-Agent": "SecondWaveBot/1.0"}) as client:
        seen = set()
        for row in rows:
            if row["address"] in seen:
                continue
            seen.add(row["address"])
            token = await token_pairs(client, row["address"])
            current = token.get("price_usd") if token else None
            entry = float(row["signal_price"] or 0)
            if not current or not entry:
                continue
            pnl = (float(current) / entry - 1) * 100
            total += pnl
            checked += 1
            winners += pnl > 0
            losers += pnl < 0
            if len(examples) < 8:
                examples.append(f"• ${row['symbol'] or '?'}: {pnl:+.2f}% (signal {datetime.fromtimestamp(row['created_at'], timezone.utc).strftime('%m-%d %H:%M')} UTC)")
    avg = total / checked if checked else 0
    await reply(
        update,
        "📈 SIGNAL PNL (PAPER TRACKING)\n"
        f"Tokens checked: {checked}\n"
        f"Positive: {winners} | Negative: {losers}\n"
        f"Average % change across latest tracked alerts: {avg:+.2f}%\n\n"
        + ("\n".join(examples) if examples else "Current prices unavailable.")
        + "\n\nThis is mark-to-market performance from alert price, not realized trading PNL. It excludes fees, slippage, failed fills, and position sizing."
    )


async def al_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply(update, "Usage: /al <Solana token contract address>\nExample: /al 7xKX... (paste the full mint address)")
        return
    address = context.args[0].strip()
    if not re.fullmatch(r"[1-9A-HJ-NP-Za-km-z]{32,44}", address):
        await reply(update, "That does not look like a valid Solana address. Paste the full token mint/contract address.")
        return
    await reply(update, "🧪 Researching token across available market and risk sources...")
    async with httpx.AsyncClient(headers={"User-Agent": "SecondWaveBot/1.0"}) as client:
        token, risk, ave = await analyze_address(client, address)
        enrich = await optional_holder_data(client, address)
        if not token:
            await reply(update, "No Solana pair data found on DexScreener for that address. It may be too new, unsupported, or the address may be incorrect.")
            return
        score, reasons, warnings = score_token(token, risk, ave)
        # Do not save /AL lookups as strategy price history; they are analysis requests.
        reasons_text = "\n".join(f"• {r}" for r in reasons[:8]) or "• No positive checks"
        warnings_text = "\n".join(f"• {w}" for w in warnings[:6]) or "• No warnings from configured checks"
        rug_risks = (risk or {}).get("risks") or []
        risk_lines = []
        for item in rug_risks[:5]:
            if isinstance(item, dict):
                risk_lines.append(f"• {item.get('name') or item.get('description') or 'Risk item'}: {item.get('level', item.get('score', 'n/a'))}")
        if not risk:
            risk_lines.append("• RugCheck report unavailable")
        await reply(
            update,
            f"🔬 SECOND-WAVE TOKEN ANALYSIS\n\n"
            f"🪙 {token.get('name')} (${token.get('symbol')})\n"
            f"CA: {address}\n"
            f"Price: ${token.get('price_usd') or 0:.10g}\n"
            f"Market cap/FDV: {fmt_money(token.get('market_cap'))}\n"
            f"Liquidity: {fmt_money(token.get('liquidity'))}\n"
            f"24h volume: {fmt_money(token.get('volume_24h'))}\n"
            f"Price change: 5m {fmt_pct(token.get('price_change_5m'))}, 1h {fmt_pct(token.get('price_change_1h'))}, 24h {fmt_pct(token.get('price_change_24h'))}\n"
            f"1h buys/sells: {token.get('buys_1h')}/{token.get('sells_1h')}\n"
            f"Strategy score: {score}/{MIN_SCORE_TO_ALERT}+ alert threshold\n\n"
            f"Positive checks:\n{reasons_text}\n\n"
            f"Risk/data warnings:\n{warnings_text}\n\n"
            f"RugCheck details:\n" + "\n".join(risk_lines[:5]) +
            f"\n\nLinks: {token.get('pair_url')}\n"
            "This is a screening report, not a guarantee. Team credibility, product utility, narrative strength, insider intent, and real PMF still require human research."
        )


async def unknown_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # Keep the bot's command surface limited to the five requested commands.
    return


def main() -> None:
    if not BOT_TOKEN:
        raise SystemExit("Missing TELEGRAM_BOT_TOKEN. Copy .env.example to .env and add your bot token.")
    init_db()
    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start_cmd))
    app.add_handler(CommandHandler("scan", scan_cmd))
    app.add_handler(CommandHandler("status", status_cmd))
    app.add_handler(CommandHandler("pnl", pnl_cmd))
    app.add_handler(CommandHandler("al", al_cmd))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, unknown_text))
    log.info("Starting Second-Wave bot. Target group: %s", GROUP_ID)
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
