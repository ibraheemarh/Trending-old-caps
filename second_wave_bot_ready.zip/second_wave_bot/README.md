
# Second-Wave Strategy Telegram Scanner

A research/alert bot for a Solana token watchlist, using DexScreener discovery/market data, optional Ave.ai data and RugCheck risk reports. It sends a Telegram group alert when a token passes configured screening thresholds.

**This is an alerting and paper-tracking tool, not an auto-trader.** It does not sign transactions, buy/sell tokens, or guarantee returns.

## Five commands

- `/scan` — run a market scan now (may take a little while)
- `/status` — scanner status, last scan and configured data sources
- `/pnl` — paper-tracks price change since alerts; not wallet/realized PNL
- `/start` — activate the recurring scanner
- `/al <contract_address>` — analyze a Solana token mint/CA

The configured destination group defaults to `-1002656806095`.

## What the first version checks

- Token discovery from DexScreener latest profiles/boosted feeds
- Optional Ave.ai trending-token discovery
- Optional GeckoTerminal new-pool discovery
- Market cap/FDV, liquidity, 24h volume, short-term price changes, buy/sell transaction counts
- Optional RugCheck report
- Heuristic narrative keywords
- Price snapshots collected by the bot to start evaluating a pullback/recovery pattern
- 24-hour alert cooldown per token

The first run will not have enough local price history to verify a complete second-wave pattern. Let it collect data for several cycles and treat early alerts as preliminary. Human checks of founder history, product/MVP, token allocations, market-making, holder clusters and narrative strength are not reliably automatable from market endpoints alone.

## API notes

- **DexScreener:** public endpoints are used for token discovery and token pairs. Follow their published rate limits.
- **Ave.ai:** your supplied API key is configured in the included private `.env` file. The bot sends it through the documented `X-API-KEY` header and uses the official V2 trending-token and token-detail routes. API quota and access depend on your account plan. If you share the project or upload it to GitHub, remove `.env` first. Because the key was pasted into chat, rotate it in Ave.ai if you believe it may have been exposed beyond this conversation.
- **RugCheck:** the token report endpoint is queried when available. A missing report is shown as a warning, not treated as proof of safety.
- **GeckoTerminal:** public new-pools endpoint is used as an additional discovery source.
- **Pump.fun / PumpPortal:** optional websocket discovery for new-token and migration events is implemented. Set `ENABLE_PUMPPORTAL=true`; add `PUMPPORTAL_API_KEY` if your PumpPortal access requires it. New-token events are candidates only and still must pass market-data/risk screening. Follow PumpPortal's current terms, connection rules and costs.
- **GMGN:** the official GMGN trade API is approval-based and is not treated as a generic public market-data API. This build does not call undocumented GMGN endpoints.
- **Solscan / Bubblemaps:** optional credentials are supported as best-effort enrichment, but API plans, authentication headers and schemas can change. Verify current provider docs and test access before relying on those checks.

## Important strategy caveats

This bot scores a **candidate**, not a confirmed trade. It cannot reliably infer whether a founder is honest, a product has PMF, a narrative will stay hot, or a token is undervalued just from price data. A keyword match is only a weak narrative hint. Market cap can be FDV or an aggregator estimate; compare sources and verify manually.

The thresholds in `.env.example` are starting values for paper testing, not recommendations to buy. You should test alert performance and false positives for multiple weeks before using it to make trading decisions.

## Local setup (Windows, macOS, Linux)

1. Install Python 3.11 or 3.12 from the official Python website.
2. Create a Telegram bot with `@BotFather` and copy the bot token.
3. Add the bot to your Telegram group. Make sure it can send messages. The group ID is already configured as `-1002656806095`.
4. Download this project and open a terminal in its folder.
5. Create an environment file:
   - Windows PowerShell: `Copy-Item .env.example .env`
   - macOS/Linux: `cp .env.example .env`
6. A prefilled `.env` file is included in the ZIP with your Ave.ai API key configured. Open `.env` and set `TELEGRAM_BOT_TOKEN` from BotFather before running the bot. Keep `.env` private and never upload it to GitHub or share the ZIP publicly.
7. Install packages:
   - Windows: `py -m venv .venv` then `.venv\Scripts\Activate.ps1`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
   - Then run `pip install -r requirements.txt`
8. Start the bot: `python bot.py`
9. In Telegram, send `/status`, then `/scan`, then `/start`.

Do not send your bot token or API keys to anyone. Do not commit `.env` to GitHub.

## Restrict commands to your own Telegram user

For production, set `TELEGRAM_ADMIN_IDS` in `.env` to your numeric Telegram user ID, e.g. `123456789`. You can get your numeric ID using a reputable Telegram ID bot. Separate multiple IDs with commas. If this setting is blank, any group member can use `/start` and `/scan`.

## GitHub upload

1. Create a new **private** GitHub repository, e.g. `second-wave-telegram-bot`.
2. Upload `bot.py`, `requirements.txt`, `.gitignore`, `Dockerfile`, `render.yaml`, `README.md`, and `.env.example`.
3. **Never upload `.env`**. `.gitignore` excludes it.
4. If using git locally:
   ```bash
   git init
   git add bot.py requirements.txt .gitignore Dockerfile render.yaml README.md .env.example
   git commit -m "Initial Second-Wave Telegram bot"
   git branch -M main
   git remote add origin YOUR_PRIVATE_REPOSITORY_URL
   git push -u origin main
   ```

## Keep it running online with Render

1. Create/sign in to Render and connect your GitHub repository.
2. Create a **Background Worker** using the repository and Dockerfile. You can also use the included `render.yaml` blueprint.
3. Add environment variables in Render's service settings:
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_GROUP_ID` = `-1002656806095`
   - `TELEGRAM_ADMIN_IDS` = your numeric Telegram user ID
   - Optional API keys
4. Deploy and open the logs. Look for `Starting Second-Wave bot`.
5. Open Telegram and test `/status`, `/scan`, and `/start`.

A continuously running worker usually requires a paid hosting plan. Confirm current provider pricing and persistent-storage availability before deployment. SQLite on an ephemeral container can reset after redeploy; for durable PNL/history, attach a persistent disk or migrate to managed PostgreSQL.

## Debugging checklist

- Bot does not respond: check `TELEGRAM_BOT_TOKEN`, bot process logs, and whether the bot was blocked.
- Cannot post to group: add the bot to the group and grant send-message permission; verify the group ID.
- No signals: use `/scan`, inspect logs, check API availability, and remember the score and hard filters must all pass.
- Ave data missing: verify API key, quota and endpoint permissions.
- No RugCheck data: the token may be unsupported, provider may be unavailable, or request may be rate-limited.
- Duplicate alerts: the default cooldown is 24 hours.
- `/pnl` differs from your actual trading: expected. It is paper performance from alert price, not wallet PNL.

## Official docs

- Ave.ai API: https://docs.ave.ai/reference/api-reference/v2
- Ave.ai account / free API key registration: https://cloud.ave.ai/register
- DexScreener API: https://docs.dexscreener.com/api/reference
- RugCheck endpoint reference: https://api.rugcheck.xyz
- GeckoTerminal API: https://apiguide.geckoterminal.com/
- PumpPortal websocket docs: https://pumpportal.fun/data-api/real-time/
- GMGN API access docs: https://docs.gmgn.ai/index/cooperation-api-integrate-gmgn-solana-trading-api
- Telegram bots: https://core.telegram.org/bots/api
